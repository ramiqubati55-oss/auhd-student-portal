# مشروع Android — AUHD

هذا مشروع Android Studio بلغة Kotlin. الواجهة المحلية داخل `app/src/main/assets/` وتُفتح من `index.html`. الروابط الأكاديمية تفتح في المتصفح الخارجي بدل تضمين أنظمة الدخول داخل WebView.

## متطلبات البناء
- Android Studio حديث
- JDK 17
- Android SDK Platform 35
- اتصال إنترنت أول مرة لتنزيل إضافات Gradle المطلوبة

## بناء Debug APK
افتح هذا المجلد في Android Studio، نفّذ Gradle Sync، ثم `Build > Build APK(s)`. الناتج المتوقع: `app/build/outputs/apk/debug/app-debug.apk`.

لم تُنشأ APK جديدة داخل بيئة التسليم الحالية لعدم توفر Android SDK وGradle وADB. لا يوجد مفتاح توقيع خاص مضمّن. استخدم مفتاحًا خاصًا وآمنًا للإصدار Release بعد موافقة الجامعة.
